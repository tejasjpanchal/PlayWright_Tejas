const { test, expect } = require('@playwright/test');

exports.Footer = class Footer {

    constructor(page) {

        this.page = page

        this.footerSocialLocator     =  page.getByText('TwitterFacebookLinkedIn')
        this.footerCopyrightLocator  =  page.getByText('© 2023 Sauce Labs. All Rights Reserved. Terms of Service | Privacy Policy')

        this.footerSocialText        =  'TwitterFacebookLinkedIn'
        this.footerCopyrightText     =  '© 2023 Sauce Labs. All Rights Reserved. Terms of Service | Privacy Policy'

        this.TwitterLinkLocator      =  page.getByRole('link', { name: 'Twitter'  });
        this.FacebookLinkLocator     =  page.getByRole('link', { name: 'Facebook' });
        this.LinkedInLinkLocator     =  page.getByRole('link', { name: 'LinkedIn' }); 

        this.TwitterURL              =  'https://twitter.com/saucelabs';
        this.FacebookURL             =  'https://www.facebook.com/saucelabs';
        this.LinkedInURL             =  'https://www.linkedin.com/company/sauce-labs/';   
        
    }    

    async verifyElementIsVisible(elementLocator) {
        await expect(elementLocator).toBeVisible(); 
    }

    async verifySocialLinkIsVisible() {
        await this.verifyElementIsVisible(this.footerSocialLocator); 
    } 

    async verifyCopyrightTextIsVisible() {
        await this.verifyElementIsVisible(this.footerCopyrightLocator); 
    }
    
    async verifySocialPage( SocialLinkLocator , SocialURL ) {
        const [socialPage] = await Promise.all( [ 
        this.page.waitForEvent('popup'),
        SocialLinkLocator.click(),
        ] );
        await expect(socialPage).toHaveURL(SocialURL);
    } 
 
    async verifyTwitterPage() {
        await this.verifySocialPage( this.TwitterLinkLocator , this.TwitterURL); 
    } 
    
    async verifyFacebookPage() {
        await this.verifySocialPage( this.FacebookLinkLocator , this.FacebookURL); 
    } 

    async verifyLinkedInPage() {
        await this.verifySocialPage( this.LinkedInLinkLocator , this.LinkedInURL); 
    } 
    
}
