
const { LoginPage } = require('./loginPage');
const { Header } = require('./headerPOM');
const { Footer } = require('./footerPOM');

exports.POManager = class POManager {

    constructor(page) {

        this.page = page;
        this.loginPage = new LoginPage(this.page);
        this.headerPOM = new Header(this.page);
        this.footerPOM = new Footer(this.page);

    }

    getLoginPage() {
        return this.loginPage;
    }

    getHeaderPOM() {
        return this.headerPOM;
    }

    getFooterPOM() {
        return this.footerPOM;
    }

}