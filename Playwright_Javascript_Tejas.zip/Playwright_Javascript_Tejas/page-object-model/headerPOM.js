const { test, expect } = require('@playwright/test');

exports.Header = class Header {

    constructor(page) {

        this.page = page

        // Primary Header Elements Locator 
        this.primaryHeaderBurgerButtonLocator           = page.locator('.bm-burger-button')
        this.primaryHeaderBmCrossButtonLocator          = page.locator('.bm-cross-button')        
        this.primaryHeaderAppLogoLocator                = page.locator('.app_logo')
        this.primaryHeaderShoppingCartLinkLocator       = page.locator('.shopping_cart_link')
        
        this.primaryHeaderBurgerMenuButtonLocator       = page.locator('#react-burger-menu-btn')
        this.primaryHeaderInventorySidebarLinkLocator   = page.locator('#inventory_sidebar_link')
        this.primaryHeaderAboutSidebarLinkLocator       = page.locator('#about_sidebar_link')
        this.primaryHeaderLogoutSidebarLinkLocator      = page.locator('#logout_sidebar_link')
        this.primaryHeaderResetSidebarLinkLocator       = page.locator('#reset_sidebar_link')

        // Primary Header Elements text
        this.primaryHeaderAppLogoText                   = 'Swag Labs'        
        this.primaryHeaderInventorySidebarText          = 'All Items'
        this.primaryHeaderAboutSidebarLinkText          = 'About'
        this.primaryHeaderLogoutSidebarLinkText         = 'Logout'
        this.primaryHeaderResetSidebarLinkText          = 'Reset App State'

        // Secondary Header Elements Locator 
        
        this.secondaryHeaderTitleLocator                = page.locator('.title')
        this.secondaryHeaderProductSortLocator          = page.locator('.product_sort_container')
        this.secondaryHeaderActiveOptionLocator         = page.locator('.active_option')
        this.SecondaryHeaderBackToProductButtonLocator  = page.locator('#back-to-products')
        this.SecondaryHeaderBackImageLocator            = page.locator('.back-image')  

        // Secondary Header Elements text

        //this.secondaryHeaderTitleText                   = 'Products'
        this.secondaryHeaderActiveOptionText            = 'Name (A to Z)'
    
    }

    // Generic Methods

    //async verifyElementIsVisible(elementLocator) {
    //    await elementLocator; 
    // }

    async verifyElementIsVisible(elementLocator) {
        await expect(elementLocator).toBeVisible(); 
    }

    async verifyElementMatchText(elementLocator,elementText) {
        await expect(elementLocator).toHaveText(elementText); 
    }

    async  clickBurgerButton(){
        await this.primaryHeaderBurgerButtonLocator.click();
    }

    async  clickBmCrossButton(){
        await this.primaryHeaderBmCrossButtonLocator.click();
    }

    // Primary Header Elements verification Methods

    async  verifyBurgerButton(){
        return await this.primaryHeaderBurgerButtonLocator
    }
    
    async  verifyBurgerButtonIsVisible(){
        await this.verifyElementIsVisible(this.primaryHeaderBurgerButtonLocator)
    }

    async  verifyBmCrossButtonIsVisible(){
        await this.verifyElementIsVisible(this.primaryHeaderBmCrossButtonLocator)
    }

    async  verifyAppLogoText(){
        await this.verifyElementMatchText(this.primaryHeaderAppLogoLocator, this.primaryHeaderAppLogoText )
    }

    async  verifyShoppingCartLinkIsVisible(){
        await this.verifyElementIsVisible(this.primaryHeaderShoppingCartLinkLocator )
    }

    async  verifyInventorySidebarText(){
        await this.verifyElementMatchText(this.primaryHeaderInventorySidebarLinkLocator, this.primaryHeaderInventorySidebarText )
    }

    async  verifyAboutSideBarText(){
        await this.verifyElementMatchText(this.primaryHeaderAboutSidebarLinkLocator, this.primaryHeaderAboutSidebarLinkText )
    }

    async  verifyLogoutSidebarText(){
        await this.verifyElementMatchText(this.primaryHeaderLogoutSidebarLinkLocator, this.primaryHeaderLogoutSidebarLinkText )
    }

    async  verifyResetSideBarText(){
        await this.verifyElementMatchText(this.primaryHeaderResetSidebarLinkLocator, this.primaryHeaderResetSidebarLinkText )
    }
    
    // Secondary Header Elements verification Methods

    async  verifyTitleText(titleText){
        await this.verifyElementMatchText(this.secondaryHeaderTitleLocator, titleText )
    }    

    async  verifyProductSortContainerIsVisible(){
        await this.verifyElementIsVisible(this.secondaryHeaderProductSortLocator)
    }

    async  verifyActiveOptionText(){
        await this.verifyElementMatchText(this.secondaryHeaderActiveOptionLocator, this.secondaryHeaderActiveOptionText )
    }

    async  verifyBackToProductButtonIsVisible(){
        await this.verifyElementIsVisible(this.SecondaryHeaderBackToProductButtonLocator)
    }

    async  verifyBackImageIsVisible(){
        await this.verifyElementIsVisible(this.SecondaryHeaderBackImageLocator)
    }
}    
