const { test, expect } = require('@playwright/test');
const { POManager } = require('../page-object-model/PageObjectManager');


test('Verify that the valid user can login and products are displayed on main product page @SMOKE', async ({ page }) => {

    // Creating object of Page Object Manager
    const poManager = new POManager(page)

    // Using Page Object Model -> LoginPage to do login
    const loginPage = poManager.getLoginPage();
    await loginPage.gotoLoginPage()
    await loginPage.login('standard_user', 'secret_sauce')

    // Verify 6 products are displayed on main products page  
    await expect(page.locator('.inventory_item_name')).toHaveCount(6);
  
    // Verify that the Products are displayed with header and footer 
    // Using Page Object Model -> headerPOM
    const headerPom = poManager.getHeaderPOM();

    // Verify Primary Header
    await headerPom.verifyBurgerButtonIsVisible();
    await headerPom.verifyAppLogoText();
    await headerPom.verifyShoppingCartLinkIsVisible();

    // Verify Secondary Header
    await headerPom.verifyTitleText('Products');
    await headerPom.verifyProductSortContainerIsVisible();
    await headerPom.verifyActiveOptionText();
    // Header Verification End

    // Verify Footer     
    // Using Page Object Model -> footerPOM 
    const footerPom = poManager.getFooterPOM();

    await footerPom.verifySocialLinkIsVisible();
    await footerPom.verifyCopyrightTextIsVisible();
    await footerPom.verifyTwitterPage();
    await footerPom.verifyFacebookPage();
    await footerPom.verifyLinkedInPage();
    // Footer Verification Ends 

    await page.close();
}
)

test('Verify Login and Logout is working for valid user @SMOKE ', async ({ page }) => {
    
    // Creating object of Page Object Manager
    const poManager = new POManager(page)

    // Using Page Object Model -> LoginPage to do login 
    const loginPage = poManager.getLoginPage();
    await loginPage.gotoLoginPage();
    await loginPage.login('standard_user', 'secret_sauce');

    // Verify Header
    // Using Page Object Model -> headerPOM
    const headerPom = poManager.getHeaderPOM();

    // try to logout 
    await headerPom.clickBurgerButton();    
    await page.locator('#logout_sidebar_link').click();

    // Verify that that login page is shown with empty username, password text field and login button
    await expect(page.locator('#user-name')).toBeEmpty();
    await expect(page.locator('#password')).toBeEmpty();
    await expect(page.locator('#login-button')).toBeVisible();

    await page.close();
}
)

test(' Purchase product flow @SMOKE', async ({ page }) => {

    // Creating object of Page Object Manager
    const poManager = new POManager(page)

    // Using Page Object Model -> LoginPage to do login 
    const loginPage = poManager.getLoginPage();
    await loginPage.gotoLoginPage()
    await loginPage.login('standard_user', 'secret_sauce')

    // Add the last product to the cart 
    const productLocator = page.locator('.inventory_item_name');

    // Click on the first product
    await productLocator.first().click();
    
    // Add product to the cart 
    await page.getByText('Add to cart').click()

    // Verify cart item Quantity in number , it should be 1
    await expect(page.locator('.shopping_cart_badge')).toHaveText('1');

    // Landing on Cart Page
    await page.locator('.shopping_cart_link').click()
    
    // Landing on "Checkout : Your Information" page 
    await page.locator('#checkout').click()

    // Verify Checkout page elements 
    // Verify cart value as the page changed  
    await expect(page.locator('.shopping_cart_badge')).toHaveText('1');
    
    // Fill out customer details
    await page.locator('#first-name').fill('testUser');
    await page.locator('#last-name').fill('testPassword');
    await page.locator('#postal-code').fill('19140');
  
    // Landing on Checkout Overview  Page
    await page.locator('#continue').click();

    // Verify cart value as the page changed  
    await expect(page.locator('.shopping_cart_badge')).toHaveText('1');
    
    // Verify Summary Info on Checkout overview
    await expect(page.getByText('Payment Information')).toBeVisible();
    await expect(page.getByText('SauceCard #31337')).toBeVisible();
    await expect(page.getByText('Shipping Information')).toBeVisible();
    await expect(page.getByText('Free Pony Express Delivery!')).toBeVisible();
    await expect(page.getByText('Price Total')).toBeVisible();
  
    // Click on Finish button to complete checkout  
    await page.locator('#finish').click();

    // Verify Checkout Complete page  
    // Verify that the purchase was successful by checking "Thank you for your order!" text and pony express image 

    await expect(page.getByRole('img', { name: 'Pony Express' })).toBeVisible();
    await expect(page.getByRole('heading', { name: 'Thank you for your order!' })).toBeVisible();
    
    // Verify that Back Home button exists on "Checkout: Complete!" page 
    await expect(page.getByRole('button', { name: 'Back Home' })).toBeVisible();

    await page.close();

}
)
