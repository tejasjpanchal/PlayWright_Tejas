const { test, expect } = require('@playwright/test');
const { POManager } = require('../page-object-model/PageObjectManager');


test('Login flow for locked_out_user @E2E @REGRESION ', async ({ page }) => {

    // Using concept of Page Object Manager  
    // PageObjectManager.js has class which contains objects of all the page object model classes
    // Instead of creating objects for all different classes of diffrent POM available just create one object of Page Object manager class 
    // which intern have objects of all page object model classes
    
    // Creating object of Page Object Manager
    const poManager = new POManager(page)

    // Using Page Object Model -> LoginPage to do login
    const loginPage = poManager.getLoginPage();
    await loginPage.gotoLoginPage()    
    await loginPage.login('locked_out_user' , 'secret_sauce');

    // Verify title  of the page "Swag Labs"
    await expect(page).toHaveTitle('Swag Labs'); 
    
    // Verify error message on the login page 
    await expect(page.getByText('Epic sadface: Sorry, this user has been locked out.')).toBeVisible();   
    
    await page.close();
}
)

test('Login flow for standard_user @E2E @REGRESION ', async ({ page }) => {

    // Creating object of Page Object Manager
    const poManager = new POManager(page)

    // Using Page Object Model -> LoginPage to do login
    const loginPage = poManager.getLoginPage();
    await loginPage.gotoLoginPage()
    await loginPage.login('standard_user', 'secret_sauce')

    // Verify title  of the page "Swag Labs"
    await expect(page).toHaveTitle('Swag Labs');

    // Verify Header
    // Using Page Object Model -> headerPOM
    const headerPom = poManager.getHeaderPOM();

    // Verify Primary Header
    await headerPom.verifyBurgerButtonIsVisible();
    await headerPom.verifyAppLogoText();
    await headerPom.verifyShoppingCartLinkIsVisible();
    await headerPom.clickBurgerButton()
    await headerPom.verifyBmCrossButtonIsVisible();
    await headerPom.verifyInventorySidebarText();
    await headerPom.verifyAboutSideBarText();
    await headerPom.verifyLogoutSidebarText();
    await headerPom.verifyResetSideBarText();
    await headerPom.clickBmCrossButton();

    // Verify Secondary Header
    await headerPom.verifyTitleText('Products');
    await headerPom.verifyProductSortContainerIsVisible();
    await headerPom.verifyActiveOptionText();
    // Header Verification End

    // Verify Footer     
    // Using Page Object Model -> footerPOM 
    const footerPom = poManager.getFooterPOM();

    await footerPom.verifySocialLinkIsVisible();
    await footerPom.verifyCopyrightTextIsVisible();
    await footerPom.verifyTwitterPage();
    await footerPom.verifyFacebookPage();
    await footerPom.verifyLinkedInPage();
    // Footer Verification Ends 

    await page.close();
}
)
