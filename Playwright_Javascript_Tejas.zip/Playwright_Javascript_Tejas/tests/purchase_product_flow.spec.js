const { test, expect } = require('@playwright/test');
const { POManager } = require('../page-object-model/PageObjectManager');

test(' Purchase product flow @E2E @REGRESION' , async ({ browser }) => {
    
    const context = await browser.newContext();
    const page = await context.newPage();

    // Using concept of Page Object Manager  
    // PageObjectManager.js has class which contains objects of all the page object model classes
    // Instead of creating objects for all different classes of diffrent POM available just create one object of Page Object manager class 
    // which intern have objects of all page object model classes
    
    // Creating object of Page Object Manager
    const poManager = new POManager(page)

    // Using Page Object Model -> LoginPage to do login 
    const loginPage = poManager.getLoginPage();
    await loginPage.gotoLoginPage()
    await loginPage.login('standard_user', 'secret_sauce')

    // Verify title  of the page "Swag Labs"
    await expect(page).toHaveTitle('Swag Labs');

    // Verify Header
    // Using Page Object Model -> headerPOM
    const headerPom = poManager.getHeaderPOM();

    // Verify Primary Header
    await headerPom.verifyBurgerButtonIsVisible();
    await headerPom.verifyAppLogoText();
    await headerPom.verifyShoppingCartLinkIsVisible();
    await headerPom.clickBurgerButton()
    await headerPom.verifyBmCrossButtonIsVisible();
    await headerPom.verifyInventorySidebarText();
    await headerPom.verifyAboutSideBarText();
    await headerPom.verifyLogoutSidebarText();
    await headerPom.verifyResetSideBarText();
    await headerPom.clickBmCrossButton();

    // Verify Secondary Header
    await headerPom.verifyTitleText('Products');
    await headerPom.verifyProductSortContainerIsVisible();
    await headerPom.verifyActiveOptionText();
    // Header Verification Ends 

    // Verify Footer 
    // Using Page Object Model -> footerPOM
    const footerPom = poManager.getFooterPOM();

    await footerPom.verifySocialLinkIsVisible();
    await footerPom.verifyCopyrightTextIsVisible();
    await footerPom.verifyTwitterPage();
    await footerPom.verifyFacebookPage();
    await footerPom.verifyLinkedInPage();
    // Footer Verification Ends 

    // Sort product low to high
    const dropdown = page.locator('.product_sort_container');
    await dropdown.selectOption('lohi');

    // Add the last product to the cart 
    const productLocator = page.locator('.inventory_item_name');

    // Create a list to store products name to use for verification on later stage to make sure same products are selected, added to the cart and purchased
    const productList = [];

    // Append name of the last product to the list
    productList.push(await productLocator.last().textContent());    

    // Click on the last product
    await productLocator.last().click();
    
    // Create list to store product price to use for verification on later stage 
    const productPriceLocator = page.locator('.inventory_details_price');    
    const productPriceList = [];

    // Append the price of product to the list
    let product1Price = await productPriceLocator.textContent()    
    product1Price = await product1Price.substring(1);    
    productPriceList.push(await product1Price);        
    
    // Add product to the cart 
    await page.getByText('Add to cart').click()

    // Verify that the "Add to cart" button changes to "Remove" button after click 
    await expect(page.getByText('Remove')).toBeVisible();

    // Verify cart item Quantity in number , it should be 1
    await expect(page.locator('.shopping_cart_badge')).toHaveText('1');

    // Go back to Products page 
    await page.getByText('Back to Product').click()

    // Sort Products on Name (A to Z) 
    await dropdown.selectOption('Name (A to Z)')

    // Append name of the top Right product to the list  
    productList.push(await productLocator.nth(1).textContent());    
    
    // Add the top Right product to the cart     
    await productLocator.nth(1).click()

    // Append the price of the second product to the list
    let product2Price = await productPriceLocator.textContent()    
    product2Price = await product2Price.substring(1);    
    productPriceList.push(await product2Price);        

    // Add Second Product to the cart 
    await page.getByText('Add to cart').click()

    // Verify cart item Quantity in number , it should be 2  
    await expect(page.locator('.shopping_cart_badge')).toHaveText('2');    

    // Landing on Cart Page
    await page.locator('.shopping_cart_link').click()
    
    // Verify Your Cart page elements 
    await headerPom.verifyTitleText('Your Cart');

    // Verify cart Item Quantity in number , it should be 2
    await expect(page.locator('.shopping_cart_badge')).toHaveText('2');

    // Verify new lements on Cart page
    await expect(page.locator('.cart_quantity_label')).toHaveText('QTY');
    await expect(page.locator('.cart_desc_label')).toHaveText('Description');

    // Verify Items in the cart matches the selected product using list  [ productList ]
    // Using below assertion method to match two array
    // https://playwright.dev/docs/api/class-genericassertions#generic-assertions-to-strict-equal

    const cartItem = await productLocator.allTextContents();    
    await expect(productList).toStrictEqual(cartItem);

    // Verify Cart Footer elements 
    await expect(page.locator('#continue-shopping')).toBeVisible();
    await expect(page.locator('.back-image')).toBeVisible();
    await expect(page.locator('#checkout')).toBeVisible();

    // Landing on "Checkout : Your Information" page 
    await page.locator('#checkout').click()

    // Verify Checkout page elements 
    // Verify cart value as the page changed  
    await expect(page.locator('.shopping_cart_badge')).toHaveText('2');

    // Verify secondary header elements
    await headerPom.verifyTitleText('Checkout: Your Information');

    // Fill out customer details
    await page.locator('#first-name').fill('Tejas');
    await page.locator('#last-name').fill('Panchal');
    await page.locator('#postal-code').fill('19141');

    // Verify Buttons on checkout page 
    await expect(page.locator('#cancel')).toBeVisible();
    await expect(page.locator('.back-image')).toBeVisible();
    await expect(page.locator('#continue')).toBeVisible();
    
    // Landing on Checkout Overview  Page
    await page.locator('#continue').click();

    // Verify Checkout:Overview page elements
    // Verify cart value as the page changed  
    await expect(page.locator('.shopping_cart_badge')).toHaveText('2');

    // Verify secondary header elements
    await headerPom.verifyTitleText('Checkout: Overview'); 

    // Verify checkout Cart Label
    await expect(page.locator('.cart_quantity_label')).toHaveText('QTY');
    await expect(page.locator('.cart_desc_label')).toHaveText('Description');

    // Verify Items on the Checkout overview matches the selected product using list  [ productList ]
    const checkoutItems = await productLocator.allTextContents()    
    await expect(productList).toStrictEqual(checkoutItems);

    // Verify Summary Info on Checkout overview
    await expect(page.getByText('Payment Information')).toBeVisible();
    await expect(page.getByText('SauceCard #31337')).toBeVisible();
    await expect(page.getByText('Shipping Information')).toBeVisible();
    await expect(page.getByText('Free Pony Express Delivery!')).toBeVisible();
    await expect(page.getByText('Price Total')).toBeVisible();

    // Verifying Total amount of item purchased without tax 
    let itemTotal = await parseFloat(productPriceList[0]) +  parseFloat(productPriceList[1]);    
    let checkoutItemTotal = await page.locator('.summary_subtotal_label').textContent();    
    checkoutItemTotal = await checkoutItemTotal.substring(13);          
    await expect(itemTotal).toStrictEqual(parseFloat(checkoutItemTotal));

    // Verifying Total amount of item purchased with tax 
    let tax = await page.locator('.summary_tax_label').textContent();
    tax = await tax.substring(6);    
    let finalTotalAmount = await parseFloat(checkoutItemTotal) + parseFloat(tax);    
    let total = await page.locator('.summary_info_label.summary_total_label').textContent();
    total = await total.substring(8);    
    await expect(finalTotalAmount).toStrictEqual(parseFloat(total));
    
    // Verify Cart footer button
    await expect(page.locator('#cancel')).toBeVisible();
    await expect(page.locator('.back-image')).toBeVisible();
    await expect(page.locator('#finish')).toBeVisible();

    // Click on Finish button to complete checkout  
    await page.locator('#finish').click();

    // Verify secondary header elements
    await headerPom.verifyTitleText('Checkout: Complete!');

    // Verify Checkout Complete page  
    // Verify that the purchase was successful by checking "Thank you for your order!" text and pony express image 

    await expect(page.getByRole('img', { name: 'Pony Express' })).toBeVisible();
    await expect(page.getByRole('heading', { name: 'Thank you for your order!' })).toBeVisible();
    await expect(page.getByText('Your order has been dispatched, and will arrive just as fast as the pony can get')).toBeVisible();
    
    // Verify that Back Home button exists on "Checkout: Complete!" page 
    await expect(page.getByRole('button', { name: 'Back Home' })).toBeVisible();

    await page.close();

}
)
